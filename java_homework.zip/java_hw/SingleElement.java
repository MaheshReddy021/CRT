public class SingleElement {
    public static int findSingle(int[] arr) {
        int result = 0;
        for (int num : arr) {
            result ^= num;
        }
        return result;
    }

    public static void main(String[] args) {
        int[] arr = {2, 3, 2, 4, 4};
        System.out.println(findSingle(arr));
    }
}
